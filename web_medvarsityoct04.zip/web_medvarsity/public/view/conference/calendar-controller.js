

(function () {

    'use strict';

    angular
        .module('app')
        .controller('CalendarCtrl', CalendarCtrl);

    CalendarCtrl.$inject = ['$scope', '$http', '$compile', 'uiCalendarConfig', '$timeout'];

    /**
     * @memberof module:app
     *
     * report based on conference attendance
     * @requires $scope,$compile,uiCalendarConfig
     * @ngInject
     */
    function CalendarCtrl($scope, $http, $compile, uiCalendarConfig, $timeout) {
        // uiCalendarConfig.calendars.myCalendar.fullCalendar('removeEvents');
        // uiCalendarConfig.calendars.myCalendar.fullCalendar('addEventSource', events);
        var date = new Date();
        var d = date.getDate();
        var m = date.getMonth();
        var y = date.getFullYear();

$scope.events = [];
$scope.calendarConfig = {
    calendar: {
        allDaySlot: false,
        timezone: 'local',
        editable: true,
        lang: 'de',
        header: {
            left:   'title',
            center: 'Custom text',
            right:  'today prev,next'
        },
        eventClick: $scope.eventClick,
        eventResizeStop: $scope.alertResize,
        eventDragStop: $scope.alertDrag,
        eventRender: $scope.eventRender,
        dayClick: $scope.dayClick,
        loading: $scope.loading
    }
};

$scope.renderCalender = function (calendarId) {
        calendarTag = $('#' + calendarId);
        calendarTag.fullCalendar('render');
    
};






 $scope.myevents = function(start, end, timezone, callback) {

 $http.get('/calendardata').then(function (res) {
               

var data = res.data;

            var events = [];


            angular.forEach(data,function(event,key){
                $scope.events.push({
                    // id: event.id,
                    title: event.title,
                    start: event.start
                });
            });


                callback(events);
        });

}

  $scope.changeView = function(view,calendar) {
     
      uiCalendarConfig.calendars[calendar].fullCalendar('changeView',view);
    };
    
    
$scope.eventSources = [$scope.events,$scope.myevents];
        function getDatas() {


            $http.get('/calendardata').then(function (res) {
                $scope.events = res.data;



                console.log(res.data)
            })

        }
       // getDatas()
    }
}());   
