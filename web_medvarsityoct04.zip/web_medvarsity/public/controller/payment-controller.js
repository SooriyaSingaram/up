
(function () {

    'use strict';

    angular
        .module('app')
        .controller('paymentController', paymentController);

    paymentController.$inject = ['dataService'];

    /**
     * @memberof module:app
     *
     * report based on conference attendance
     * @requires dataService
     * @ngInject
     */
    function paymentController(dataService) {
        var self = this;
        self.ccavenue = ccavenue;
        
        function ccavenue(pay) {
if(pay == undefined){
    pay = {};
}
            pay.merchant_id = '10222';
            pay.order_id = 'sss';
            pay.currency = 'INR';
            pay.amount = '1.00'
            pay.redirect_url = 'http://127.0.0.1:3001/ccavResponseHandler';
            pay.cancel_url = "http://127.0.0.1:3001/ccavResponseHandler";
            pay.language = 'EN'


            dataService.saveData('/ccavRequestHandler', pay).then(successHandler, errorHandler); //passing the  POST URL to dataService ,its sucesss returns the data
            function successHandler(response) {
                console.log(response)

            }
            function errorHandler(e) {
                console.log(e)
            }
        }







    }


}());     