(function () {

    'use strict';

    angular
        .module('app')
        .controller('signupController', signupController);

    signupController.$inject = ['dataService','$stateParams', '$http', '$state', '$scope', 'AlertService', '$rootScope','$timeout'];

    /**
     * @memberof module:register
     *
     * Registering user data
     * @requires dataService
     * @ngInject
     * AlertService
     */
    function signupController(dataService,$stateParams, $http, $state, $scope, AlertService, $rootScope,$timeout) {

        var self = this,

            data = {},
            url = "/register";

        // self.check = check;
console.log($stateParams)
if($stateParams.id == 'facebook'){
  fbData()
  
}
else if($stateParams.id == 'google'){
    gmailLoginData()

}
else if($stateParams.id == 'linkedin'){
    linkedinLoginData()

}

        function fbData(){
            self.user={};
             hello('facebook').api('me').then(fbDetail, function (e) {
                    AlertService('Whoops! ' + e.error.message);
                });

               function fbDetail(json){
                $scope.$apply(function(){
                self.user.first_name = json.first_name;
                    self.user.last_name = json.last_name;
                    self.user.id = json.id;
console.log('$scope second',$scope);
                    $scope.test='surya_new';
                    console.log('$scope.test',$scope.test);
                });
               }   
                    }

         function gmailLoginData() {
 hello('google').api('me').then(googleDetail, function (e) {
                    AlertService('Whoops! ' + e.error.message);
                });
function googleDetail(json){
$scope.$apply(function(){
                    if (json.email) {
                        self.user = {};
                        self.user.email = json.email;
                    }
                })
}
        }
 function linkedinLoginData(){
     hello('linkedin').api('me').then(linkedDetail, function (e) {
                    AlertService('Whoops! ' + e.error.message);
                });
     function linkedDetail(json){
$scope.$apply(function(){
                    if (json.id) {
                        self.user = {};
                        $rootScope.fName = json.firstName;
                        $rootScope.lName = json.lastName;
                        self.user.first_name = $rootScope.fName;
                        self.user.last_name = $rootScope.lName
                    }         
                });         
            }
        }
        self.read = true;
        self.addRegister = addRegister;

        // Handles the error while getting false function
        function errorHandler(e) {
            console.log(e);
        }

        /**
         * Add the registers details using data service passing the URL.
         * Its first validate the registers details and allow to add data.
         * On success call getting all registers details in a summary list.
         * @param customerType
         */
        function addRegister(register,valid) {
           if(!valid){
               $scope.class = 'red';
           }
            else{
               $scope.class = 'blue'; 
            }
            if ($rootScope.gmailAccess) {
                register.gmailAccess = $rootScope.gmailAccess;
            }
            dataService.saveData(url, register).then(successHandler, errorHandler); //passing the  POST URL to dataService ,its sucesss returns the data
            function successHandler(responseData) {
                console.log("--User Data-->", responseData)
             
                var patt = new RegExp("email");
                var mpatt = new RegExp("mobile");
                var mesEmail = patt.test(responseData.message);
                var mesMobile = mpatt.test(responseData.message);
                console.log(mesEmail);
                console.log(mesMobile);
                if (mesEmail && mesMobile) {
                     $scope.validEmailErr = true;
                     $scope.validMobileErr =true;
                   // AlertService.warn('Email Id and Mobile Number already exists');

                }
                else if (mesEmail && !mesMobile) {
                    $scope.validEmailErr = true;
                     $scope.validMobileErr =false;
                    //AlertService.warn('Email Id  already exists');
                }
                else if (!mesEmail && mesMobile) {
                    $scope.validMobileErr =true;
                      $scope.validEmailErr = false;
                   // AlertService.warn('Mobile Number already exists');
                }
                else {
                   AlertService.success(responseData.message);
                    $scope.validEmailErr = false;
                     $scope.validMobileErr =false;
                    $state.go('login')
                }
                   

            }

        }
        //Qualifiction list
        function education() {
            self.educationFields = ['MBBS', 'Undergraduate - MBBS', 'Post Graduate - Medical', 'Others',
                'Nursing - GNM', 'Nursing - ANM', 'Alternative Medicine - BHMS', 'Alternative Medicine - BEMS', 'Alternative Medicine - BUMS', 'Alternative Medicine - BAMS',
                'Alternative Medicine - BNYS', 'PBBSC', 'MBA', 'MCA', 'MSc', 'MOT', 'BTech', 'BBA', 'BCA', 'MTech', 'B Pharmacy', 'D Pharmacy',
                'M Pharmacy', 'MCom', 'BOT', 'BDS', 'MDS', 'BPT', 'MPT', 'MBCHB']
        }
        education()

        //country codes
        function getCodes() {
            $http.get('/register/getData').then(function (response) {
                console.log(response);
                self.codes = response.data;
            }, function (response) {
                // self.handleError(response);
            })
        }
        getCodes()


        //payment option
        $scope.pay = function () {
            dataService.saveData('/cca', { data: 'a' }).then(successHandler, errorHandler); //passing the  POST URL to dataService ,its sucesss returns the data
            function successHandler(response) {
                console.log(response)
            }
        }
        //linked in
       // $scope.myMessage;
        // var myInt = setInterval(function () {
        //     if (document.getElementById('myMessage').value !== '') {
        //         $scope.myMessage = document.getElementById('myMessage').value;
        //         console.log($scope.myMessage);
        //         $rootScope.linkedInMessage = $scope.myMessage;

        //         var user = $scope.myMessage.split("/");
        //         self.user.first_name = user[0];
        //         self.user.last_name = user[1];
        //         $scope.$apply();
        //         clearInterval(myInt);
        //         if ($rootScope.linkedInMessage) {
        //           //  $state.go('manual-register')
        //         }
        //     }
        // }, 150);

        //google login
        self.user = {}
        function onSignIn(googleUser) {
            var profile = googleUser.getBasicProfile();
            console.log('Name: ' + profile.getName());
            var name = profile.getName().split(" ");
            self.user.first_name = name[0];
            self.user.last_name = name[1];
            self.user.email = profile.getEmail();

        }
        window.onSignIn = onSignIn;

        //gmail profile data
        function getProfileData() { // Use the API call wrapper to request the member's basic profile data
            IN.API.Profile("me").fields("id,firstName,lastName,email-address,picture-urls::(original),public-profile-url,location:(name)").result(function (me) {
                var profile = me.values[0];
                var id = profile.id;
                var firstName = profile.firstName;
                var lastName = profile.lastName;
                var emailAddress = profile.emailAddress;
                var pictureUrl = profile.pictureUrls.values[0];
                var profileUrl = profile.publicProfileUrl;
                var country = profile.location.name;
            });
        }
    }
}());     