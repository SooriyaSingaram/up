
(function () {

    'use strict';

    angular
        .module('app')
        .controller('lectureDetailController', lectureDetailController);

    lectureDetailController.$inject = ['dataService', '$stateParams', '$scope', '$location','$window'];

    /**
     * @memberof module:app
     *
     * report based on conference attendance
     * @requires dataService
     * @ngInject
     */
    function lectureDetailController(dataService, $stateParams, $scope, $location,$window) {
      $window.scrollTo(0, 0);
        var vm = this;
        console.log($stateParams)
        $scope.doctor = $stateParams.Dr;
        var utc = new Date(Date.now());
        function upcomingConference() {
            dataService.getData('/api/v1/conferences/upcoming').then(function (response) {
                vm.upcomings = response;
                console.log(vm.upcomings)

            }, function (response) {
                if (response.status == 'Payment') {
                    $location.path('/payment')
                }
            });
        }
        upcomingConference();

        function getAllConferences() {
            var mappedId = $stateParams.id;

            dataService.getData('/api/v1/conferences/getAllConference').then(function (response) {
                console.log(response)
                var data = response;
                vm.confById = angular.forEach(data, function (mapped) {

                    if (mapped.id == mappedId) {
                        $scope.conferenceData = mapped;

                        $scope.presenterImage = $scope.conferenceData.presenterImage
                        if ($scope.presenterImage) {
                            $scope.dynamicImage = true;
                            $scope.speakerImages = 'profiles/' + $scope.presenterImage;
                        }
                        else {
                            $scope.dynamicImage = false;
                        }
                        $scope.copyUrl = $location.absUrl();
                        $scope.whatsappData = "https://web.whatsapp.com/send?text=" + $scope.copyUrl;
                        


                        var d = mapped.start_time
                        var upcoming_date = new Date(d);
                        console.log(upcoming_date);

                        // var diff = (upcoming_date - utc) / 3600000;

                        var hours = Math.abs(upcoming_date - utc) / 36e5;
                        // console.log(hours);

                        console.log(upcoming_date.getTime());
                        console.log(utc.getTime());

                        var diff = Math.abs(upcoming_date.getTime() - utc.getTime()) / 3600000;
                        console.log(diff);
                    }

                })

            })


        }
        getAllConferences();
        $scope.similarLecture = [];

        function speakerProfile() {
            dataService.getData('/speakers').then(function (response) {
                self.speakers = response;
                console.log(response)
                var res = [];
                for (var x in response) {
                    response.hasOwnProperty(x) && res.push(response[x])
                }
                $scope.speakerValue = [];

                angular.forEach(res, function (key, value) {
                    $scope.speakerValue.push(key[0])
                });
                for (var x in response) {
                    if (x == $scope.doctor) {
                        console.log(response[x]);
                        var similarity = response[x];
                        var similar = [];
                        for (var y in similarity) {
                            similarity.hasOwnProperty(y) && similar.push(similarity[y])
                        }
                        // $scope.similarLecture = similar;
                        angular.forEach(similar, function (data) {
                            var myData = {};
                            myData = data;
                            var d = data.time
                            var upcoming_date = new Date(d);

                            var leftDays = Math.round((upcoming_date - utc) / (1000 * 60 * 60 * 24));
                            myData.leftDays = leftDays;
                            $scope.similarLecture.push(myData);


                        })
                    }

                }

                console.log($scope.speakerValue)
            });
        }

        speakerProfile()



    }


}());     