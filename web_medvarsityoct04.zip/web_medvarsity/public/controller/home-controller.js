(function () {

    'use strict';

    angular
        .module('app')
        .controller('homeController', homeController);

    homeController.$inject = ['dataService', '$scope', 'Upload', '$timeout', 'authService', '$location','$window'];

    /**
     * @memberof module:app
     *
     * report based on conference attendance
     * @requires dataService
     * @ngInject
     */
    function homeController(dataService, $scope,Upload, $timeout, authService, $location,$window) {
        $window.scrollTo(0, 0);
        var self = this;
        self.getUserDetail = getUserDetail;
        self.logoutUser = logoutUser;
        self.educationFields = ['MBBS', 'Undergraduate - MBBS', 'Post Graduate - Medical', 'Others',
                'Nursing - GNM', 'Nursing - ANM', 'Alternative Medicine - BHMS', 'Alternative Medicine - BEMS', 'Alternative Medicine - BUMS', 'Alternative Medicine - BAMS',
                'Alternative Medicine - BNYS', 'PBBSC', 'MBA', 'MCA', 'MSc', 'MOT', 'BTech', 'BBA', 'BCA', 'MTech', 'B Pharmacy', 'D Pharmacy',
                'M Pharmacy', 'MCom', 'BOT', 'BDS', 'MDS', 'BPT', 'MPT', 'MBCHB']
        function getAllConferences() {
            dataService.getData('/api/v1/home/getAllConference').then(function (response) {
                self.presenders = response;
                //var pic = response[0].presenterImage;
               // $scope.presenterImage = pic;
                console.log(self.presenders);
                var webinarImage = response[0].webinarImage;
                $scope.webinarImage = webinarImage 
            });
        }

        function logoutUser() {

            authService.logout();
             $window.location.reload();
            $location.path('/');
           
        }

        function getUserDetail() {
            var data = authService.getUserInfo();
            $scope.userProfileId = 'profiles/'+data._id+'.jpg';
            if (data._id) {
                $scope.hideTrail = true;
            }
            else {
                $scope.hideTrail = false;
            }
            dataService.getData('/register/' + data._id).then(function (response) {
                self.userData = response;
            });
        }
        function init() {
            upcomingConference();
            getAllConferences();
            speakerProfile();
            getUserDetail()
        }
        function upcomingConference() {
            dataService.getData('/api/v1/conferences/upcoming').then(function (response) {
                self.upcomings = response;
                console.log("0------_)))))0000----", response)
                var pic = response[0].presenterImage;
                $scope.presenterImage = pic;
                var webinarImage = response[0].webinarImage;
                $scope.webinarImage = webinarImage 
                console.log("____----->>>", pic)

            }, function (response) {
                // if (response.status == 'Payment') {
                //     $location.path('/payment')
                // }
            });
        }

        function speakerProfile() {
            dataService.getData('/speakers').then(function (response) {
                self.speakers = response;
                console.log(response)
                var res = [];
                for (var x in response) {
                    response.hasOwnProperty(x) && res.push(response[x])
                }
                $scope.speakerValue = [];

                angular.forEach(res, function (key, value) {
                    $scope.speakerValue.push(key[0])
                });
                console.log($scope.speakerValue)
            });
        }

        self.fblogin = fblogin;
        function fblogin() {
            console.log("cvb")
            dataService.getData('/auth/facebook').then(function (response) {
                self.presenders = response;
                console.log(self.presenders)
            });
        }

        $scope.updateProfile = function(id,data){
     dataService.updateData('/register',id,data).then(function (response) {
         $(".modal-backdrop").hide();
        console.log(response);
            },function(e){
                console.log("error");
                console.log(e)
            })
}

$scope.$watch('gFiles', function () {
            $scope.upload($scope.gFiles);
        });


        $scope.upload = function (gFiles) {
            if (gFiles && gFiles.length) {
                for (var i = 0; i < gFiles.length; i++) {
                    var file = gFiles[i];
                    if (!file.$error) {
                        console.log(file)
                        
                        var nameId =  authService.getUserInfo()._id;
                        Upload.upload({
                            url: '/profilepicture',
                            data: {
                                file: file,
                                id:nameId
                            }
                        })
                            .then(function (response) {
                                $timeout(function () { });
                            }, function (response) {
                                console.log('Error status: ' + response.status);
                            }, function (evt) {
                                var progressPercentage = parseInt(100.0 *
                                    evt.loaded / evt.total);
                                $scope.progress = progressPercentage + '% ';
                            });
                    }
                }
            }
        }
        
        $scope.refreshProfile = function(){
    location.reload()
}
$scope.deleteUser = function(id){
    dataService.deleteData('/register',id).then(function (response) {
        console.log(response);
        
        location.reload();
        logoutUser()
        
            },function(e){
                console.log("error");
                console.log(e)
            })
}
        init()



    }


}());     