(function () {

    'use strict';

    angular
        .module('app')
        .controller('conferenceController', ConferenceController)
        .filter('startFrom', startFrom)

    ConferenceController.$inject = ['dataService', '$scope', 'Upload', '$timeout', 'authService', '$location', 'AlertService'];

    /**
     * @memberof module:register
     *
     * CRUD application is performed and also displays the data
     * @requires dataService
     * @ngInject
     */
    function ConferenceController(dataService, $scope, Upload, $timeout, authService, $location, AlertService) {

        var vm = this;
        vm.addConf = addConf;
        vm.addToFav = addToFav;
        vm.logoutUser = logoutUser;
        vm.searchByIndex = searchByIndex;
        vm.sendemail = sendemail;
        vm.searchByES = searchByES;
        vm.downloadPdf = downloadPdf;
        vm.reminder = reminder;

        function searchByES(a) {
            console.log(a)
            dataService.saveData('/api/v1/conferences/suggest/', { data: a }).then(function (response) {
                console.log(response.data)
            }, function (response) {
                errorHandler(response);
            });
        }

        function searchByIndex(a) {
            dataService.saveData('/api/v1/conferences/search', { data: a }).then(function (response) {
                console.log(response.data)
            }, function (response) {
                errorHandler(response);
            });
        }


        function logoutUser() {
            authService.logout();
            $location.path('/')
        }

        /////////////////
        function addConf(reqData) {
            // var reqData = {
            //     "channel_id": "doodleblue3",
            //     "title": "title name def"
            // };
            reqData.channel_id = 'doodleblueTest';
            dataService.saveData('/api/v1/conferences/create', reqData).then(function (response) {
                console.log(response)
                $location.path('/view-conference')
            }, function (response) {
                errorHandler(response);
            });
        }
        // addConf()
        function addToFav(a) {
            a.favourite = true;
            dataService.updateData('/api/v1/conferences', a._id, a).then(function (response) {
                console.log(response)
            }, function (response) {
                errorHandler(response);
            });


        }
        function sendemail(a) {
            dataService.saveData('/api/sendmail', { data: a }).then(function (response) {
                console.log(response.data)
            }, function (response) {
                errorHandler(response);
            });
        }

        function education() {

            vm.educationFields = ['MBBS', 'Undergraduate - MBBS', 'Post Graduate - Medical', 'Others',
                'Nursing - GNM', 'Nursing - ANM', 'Alternative Medicine - BHMS', 'Alternative Medicine - BEMS', 'Alternative Medicine - BUMS', 'Alternative Medicine - BAMS',
                'Alternative Medicine - BNYS', 'PBBSC', 'MBA', 'MCA', 'MSc', 'MOT', 'BTech', 'BBA', 'BCA', 'MTech', 'B Pharmacy', 'D Pharmacy',
                'M Pharmacy', 'MCom', 'BOT', 'BDS', 'MDS', 'BPT', 'MPT', 'MBCHB']
        }
        education()


        function errorHandler(e) {
            console.log(e.toString());
        }
        function getAllConferences() {
          dataService.getData('/api/v1/conferences/getAllConference').then(function (response) {
                vm.confData = response;
                vm.confData.forEach(function(value, index){
                    var now = new Date()
                    var afterOneHour=now.setHours(new Date(value.start_time).getHours() + 1)
                    value.isStarted =( (new Date(value.start_time) >= now) || afterOneHour);
                })
                // console.log("&&&&&&&&&&&&&&&&&&&");
                // console.log(vm.confData);
             var date1 = new Date();
                date1.setHours(0,0,0,0);
                console.log(date1)
                 vm.liveLectures =  response.filter(function(con) {
                     var start_time = new Date(new Date(con.start_time).setHours(0,0,0,0));
                     console.log(start_time)
                return (start_time.valueOf() == date1.valueOf());
            })
                //
                console.log( vm.liveLectures)

            }, function (response) {
                if (response.status == 'Payment') {
                    $location.path('/payment')
                }
            });
        }
        getAllConferences();

        function upcomingConference() {
            dataService.getData('/api/v1/conferences/upcoming').then(function (response) {
                vm.upcomings = response;
                console.log(vm.upcomings)

            }, function (response) {
                if (response.status == 'Payment') {
                    $location.path('/payment')
                }
            });
        }
        upcomingConference();


        vm.del = del;
        function del(a) {
            console.log(a)
            dataService.deleteData('/api/v1/conferences/delete', a.id).then(function (response) {
                console.log(response.data)
            }, function (response) {
                errorHandler(response);
            });
        }
        vm.getById = getById;
        function getById(a) {
            console.log(a)

            dataService.getDataById('/api/v1/conferences', a).then(function (response) {
                vm.confById = response
                console.log(vm.confById)
            }, function (response) {
                errorHandler(response);
            });
        }

        vm.reportData = reportData;
        function reportData(a) {
            var timeDuration = a.duration;
            var data = a.id;

           
            dataService.getDataById('/api/v1/conferences/getAllReport', data).then(function (response) {
                vm.report = response.attendees;
                if(vm.report){
                    vm.attendeesNo = vm.report.length
                }
                else{
                    vm.attendeesNo = 0
                }
                mappedUsers(timeDuration)
            }, function (response) {
                errorHandler(response);
            });
        }

        vm.updateConf = updateConf;
        function updateConf(a) {
            console.log(a)
            dataService.updateData('/api/v1/conferences/update', a.id, a).then(function (response) {
                vm.confById = response.data
            }, function (response) {
                errorHandler(response);
            });
        }
        // function getAllUser() {
        //     dataService.getData('/register').then(function (response) {
        //         vm.allUsers = response;

        //     }, function (response) {
        //         console.log(response)
        //     });
        // }
        // getAllUser()
        vm.attendeesDetail = [];
        function mappedUsers(a) {

            angular.forEach(vm.allUsers, function (rep) {
                angular.forEach(vm.report, function (det) {
                    if (rep.email == det.email) {
                        rep.duration = det.total_duration;
                        if (rep.duration < (a * 0.9)) {
                            rep.eligible = 'Yes';
                            sendMail(rep)
                        }
                        else {
                            rep.eligible = 'No';
                            sendMail(rep)
                        }

                        vm.attendeesDetail.push(rep);


                    }
                })
            })


        }
        function speakerProfile() {
            dataService.getData('/speakers').then(function (response) {
                self.speakers = response;
                
                var res = [];
                for (var x in response) {
                    response.hasOwnProperty(x) && res.push(response[x])
                }
                $scope.speakerValue = [];

                console.log("----------->>>", $scope.speakerValue)
                angular.forEach(res, function (key, value) {
                    $scope.speakerValue.push(key[0])
                });
                
            });
        }
        speakerProfile()
        function downloadPdf(heading) {
            var doc = new jsPDF('p', 'pt');
            var elem = document.getElementById("pdfgrid");
            var res = doc.autoTableHtmlToJson(elem);
            doc.text(heading, 40, 30);
            doc.autoTable(res.columns, res.data);
            doc.save("document.pdf");
        }


        $scope.$watch('gFiles', function () {
            $scope.upload($scope.gFiles);
        });
        $scope.upload = function (gFiles) {
            if (gFiles && gFiles.length) {
                for (var i = 0; i < gFiles.length; i++) {
                    var file = gFiles[i];
                    if (!file.$error) {
                        console.log(file)
                        Upload.upload({
                            url: '/filesdata',
                            data: {
                                file: file
                            }
                        })
                            .then(function (response) {
                                $timeout(function () { });
                            }, function (response) {
                                console.log('Error status: ' + response.status);
                            }, function (evt) {
                                var progressPercentage = parseInt(100.0 *
                                    evt.loaded / evt.total);
                                $scope.progress = progressPercentage + '% ';
                            });
                    }
                }
            }
        }
        function reminder(a) {
            a.reminder = true;
            dataService.updateData('/api/v1/conferences', a._id, a).then(function (response) {
                console.log(response)
            }, function (response) {
                errorHandler(response);
            });
        }

        function getReminder() {
            dataService.getData('/api/v1/conferences/reminder/list').then(function (response) {
                //   AlertService.success(response);

            })
        }
        function sendMail(a) {
            console.log(a)
            dataService.saveData('/api/v1/conferences/mail', a).then(function (response) {
                console.log(response)
            })
        }

        function recommented() {
            dataService.getDataById('/register', authService.getUserInfo()._id).then(function (response) {
                var userData = response.category;
                dataService.saveData('/api/v1/conferences/recommented', { data: userData }).then(function (resData) {
                    vm.recomentedList = resData;
                })
            }, function (response) {
                errorHandler(response);
            });
        }
        function endedConference() {
            dataService.getData('/api/v1/conferences/completed/list').then(function (response) {
                vm.completedConference  = response;
            })
        }


         $scope.enterConf = function (conf_id) {
            var data = authService.getUserInfo();
            dataService.getData('/register/' + data._id).then(function (response) {
                $scope.userData = response;
                //  $scope.registerField =false;
                var reqData = {
                    "id": conf_id,
                    "attendee_email": $scope.userData.email,
                    "attendee_name": $scope.userData.first_name,
                    "exit_uri": "http://assimilate.medvarsity.com/#/"
                }
                console.log("$$$$$$$$$$$$$$$$$$$$$$");
                dataService.enterConference2('/api/v1/conferences/enter', reqData).then(function (response) {
                    // $scope.registerField =true;
                    console.log("success")
                    console.log(response)
                    $location.href(response.data.url)
                    // $location.path('/adminDashboard')
                }).catch(function (response) {
                    // if(response)
                    console.log("error")
                    console.log(response)

                    //errorHandler(response);
                });
            });


        }
        $scope.registerField = false;

        $scope.registerConf = function (conf_id, index) {
            var data = authService.getUserInfo();
            dataService.getData('/register/' + data._id).then(function (response) {
                $scope.userData = response;

                var reqData = {
                    "id": conf_id,
                    "email": $scope.userData.email,
                    "first_name": $scope.userData.first_name,
                    "last_name": $scope.userData.last_name,
                    "temporary_password": "user@123"
                }
                console.log(reqData);
                dataService.putData2('/api/v1/conferences/register', reqData).then(function (response) {
                    // $scope.registerField =true;

                    console.log("success")
                    console.log(response)
                    // $location.path('/dashboard')
                    location.href = response.data.url;
                    // $location.path('/adminDashboard')
                }).catch(function (response) {
                    // if(response)
                    console.log("error")
                    console.log(response)
                    var a = '#error-msg' + index;
                    console.log("#######", a)
                    $(a).html(response.data.message)
                    //errorHandler(response);
                });
            });


        }

        recommented()
        getReminder()
        endedConference()
    }


}());


function startFrom() {
    return function (input, start) {
        console.log(input);
        start = +start; //parse to int
        return input.slice(start);
    }
}

