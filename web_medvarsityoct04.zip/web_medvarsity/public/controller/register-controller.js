(function () {

    'use strict';

    angular
        .module('app')
        .controller('registerController', RegisterController);

    RegisterController.$inject = ['dataService', '$http', '$state', '$scope', 'AlertService', '$rootScope'];

    /**
     * @memberof module:register
     *
     * Registering user data
     * @requires dataService
     * @ngInject
     * AlertService
     */
    function RegisterController(dataService, $http, $state, $scope, AlertService, $rootScope) {

        var self = this,

            data = {},
            url = "/register";

        // self.check = check;
        $scope.facebookLogin = function (network) {
            self.user = {};
            hello(network).login({ scope: 'email', force: true }, function (e) {
                console.log("login-scope", e);
            }).then(function () {
                $state.go('manual-register',{id:'facebook'});
               

            })

        }
        self.read = true;
        self.addRegister = addRegister;

        // Handles the error while getting false function
        function errorHandler(e) {
            console.log(e);
        }

        /**
         * Add the registers details using data service passing the URL.
         * Its first validate the registers details and allow to add data.
         * On success call getting all registers details in a summary list.
         * @param customerType
         */
        function addRegister(register,valid) {
           if(!valid){
               $scope.class = 'red';
           }
            else{
               $scope.class = 'blue'; 
            }
            if ($rootScope.gmailAccess) {
                register.gmailAccess = $rootScope.gmailAccess;
            }
            dataService.saveData(url, register).then(successHandler, errorHandler); //passing the  POST URL to dataService ,its sucesss returns the data
            function successHandler(responseData) {
                var patt = new RegExp("email");
                var mpatt = new RegExp("mobile");
                var mesEmail = patt.test(responseData.message);
                var mesMobile = mpatt.test(responseData.message);
                console.log(mesEmail);
                console.log(mesMobile);
                if (mesEmail && mesMobile) {
                    $scope.validEmailErr = true;
                     $scope.validMobileErr =true;
                   //AlertService.warn('Email Id and Mobile Number already exists');

                }
                else if (mesEmail && !mesMobile) {
                    //AlertService.warn('Email Id  already exists');
                    $scope.validEmailErr = true;
                }
                else if (!mesEmail && mesMobile) {
                    //AlertService.warn('Mobile Number already exists');
                    $scope.validMobileErr =true;
                }
                else {
                    $scope.validEmailErr = false;
                     $scope.validMobileErr =false;
                 //   AlertService.success(responseData.message);
                }
                   $state.go('home')

            }

        }
        //Qualifiction list
        function education() {
            self.educationFields = ['MBBS', 'Undergraduate - MBBS', 'Post Graduate - Medical', 'Others',
                'Nursing - GNM', 'Nursing - ANM', 'Alternative Medicine - BHMS', 'Alternative Medicine - BEMS', 'Alternative Medicine - BUMS', 'Alternative Medicine - BAMS',
                'Alternative Medicine - BNYS', 'PBBSC', 'MBA', 'MCA', 'MSc', 'MOT', 'BTech', 'BBA', 'BCA', 'MTech', 'B Pharmacy', 'D Pharmacy',
                'M Pharmacy', 'MCom', 'BOT', 'BDS', 'MDS', 'BPT', 'MPT', 'MBCHB']
        }
        education()

        //country codes
        function getCodes() {
            $http.get('/register/getData').then(function (response) {
                console.log(response);
                self.codes = response.data;
            }, function (response) {
                // self.handleError(response);
            })
        }
        getCodes()

        $scope.gmailLogin = function (network) {


            hello(network).login({ scope: "email" }, function (e) {
               
            }).then(function () {
                
                    $state.go('manual-register',{id:'google'});
               
            })

        }
$scope.linkedinLogin = function(network){
     hello(network).login({ scope: "email" }, function (e) {
               console.log(e)
            }).then(function () {
                
                    $state.go('manual-register',{id:'linkedin'});
                
            })
}
        //payment option
        $scope.pay = function () {
            dataService.saveData('/cca', { data: 'a' }).then(successHandler, errorHandler); //passing the  POST URL to dataService ,its sucesss returns the data
            function successHandler(response) {
                console.log(response)
            }
        }
        //linked in
       // $scope.myMessage;
        // var myInt = setInterval(function () {
        //     if (document.getElementById('myMessage').value !== '') {
        //         $scope.myMessage = document.getElementById('myMessage').value;
        //         console.log($scope.myMessage);
        //         $rootScope.linkedInMessage = $scope.myMessage;

        //         var user = $scope.myMessage.split("/");
        //         self.user.first_name = user[0];
        //         self.user.last_name = user[1];
        //         $scope.$apply();
        //         clearInterval(myInt);
        //         if ($rootScope.linkedInMessage) {
        //           //  $state.go('manual-register')
        //         }
        //     }
        // }, 150);

        //google login
        self.user = {}
        function onSignIn(googleUser) {
            var profile = googleUser.getBasicProfile();
            console.log('Name: ' + profile.getName());
            var name = profile.getName().split(" ");
            self.user.first_name = name[0];
            self.user.last_name = name[1];
            self.user.email = profile.getEmail();

        }
        window.onSignIn = onSignIn;

        //gmail profile data
        function getProfileData() { // Use the API call wrapper to request the member's basic profile data
            IN.API.Profile("me").fields("id,firstName,lastName,email-address,picture-urls::(original),public-profile-url,location:(name)").result(function (me) {
                var profile = me.values[0];
                var id = profile.id;
                var firstName = profile.firstName;
                var lastName = profile.lastName;
                var emailAddress = profile.emailAddress;
                var pictureUrl = profile.pictureUrls.values[0];
                var profileUrl = profile.publicProfileUrl;
                var country = profile.location.name;
            });
        }
    }
}());     