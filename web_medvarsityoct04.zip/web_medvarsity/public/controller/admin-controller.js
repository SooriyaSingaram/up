(function () {

    'use strict';

    angular
        .module('app')
        .controller('adminController', adminController);

    adminController.$inject = ['dataService', '$rootScope', '$scope', '$state', '$http', 'Upload', '$timeout', '$window', 'authService', '$location', 'AlertService'];

    /**
     * @memberof module:register
     *
     * CRUD application is performed and also displays the data
     * @requires dataService
     * @ngInject
     */
    function adminController(dataService, $rootScope, $scope, $state, $http, Upload, $timeout, $window, authService, $location, AlertService) {

        var vm = this;

        vm.addConf = addConf;
        vm.logoutUser = logoutUser;

        function logoutUser() {
            authService.logout();
            $location.path('/')
        }

        function userPercentage() {
            dataService.getData('/usersPaymentInfo').then(function (response) {
                console.log("*********************************");
                // console.log(response)
                $scope.paidUsers_list = response.paidUsers;
                $scope.unPaidUsers_list = response.unPaidUsers;
                $scope.paidLength = response.paidLength;
                $scope.unPaidLength = response.unPaidLength;
                $scope.totalUsers = response.paidLength + response.unPaidLength;
                $scope.paidUsers = response.paidPercent;
                $scope.unPaidUsers = response.unPaidPercent;
                setTimeout(function () {
                    $('#myTable').DataTable();
                    $('#myTabletwo').DataTable();
                }, 0)
                console.log("######################");
                console.log($scope.paidUsers, $scope.unPaidUsers)
            }, function (response) {
                errorHandler(response);
            });
        }

        userPercentage();

        $scope.adminLogin = function (reqData) {

            console.log(reqData);

            var options = {
                method: 'POST',
                cache: false,
                url: '/adminLoginPost',
                data: reqData
            };

            function handleSuccess(data, status, headers, config) {
                 sessionStorage.setItem("adminDataToken", data.data);
                console.log($rootScope.userAuth);
                $state.go('admin-dashboard');


            }

            function handleError(data, status, headers, config) {
                // deferred.reject(data, status, headers, config);
                console.log(status);
            }
            $http(options).success(handleSuccess).error(handleError);
            // return deferred.promise;

        }
        $scope.limit = 5;
        $scope.incrementLimit = function (limitValue) {
            $scope.limit = limitValue;
        };
        /////////////////
        function graphData() {
            dataService.getData('/userGraphInfo').then(function (response) {
                console.log("$$$$$$$$$$$$$$$$$$$$$$$$$");
                console.log(response);
                $scope._yGraphMetrics = response;

            });
        }
        graphData();
        $scope.type = ['webinars', 'conference', 'task', 'events'];
        //Qualifiction list

        $scope.educationFields = ['MBBS', 'Undergraduate - MBBS', 'Post Graduate - Medical', 'Others',
            'Nursing - GNM', 'Nursing - ANM', 'Alternative Medicine - BHMS', 'Alternative Medicine - BEMS', 'Alternative Medicine - BUMS', 'Alternative Medicine - BAMS',
            'Alternative Medicine - BNYS', 'PBBSC', 'MBA', 'MCA', 'MSc', 'MOT', 'BTech', 'BBA', 'BCA', 'MTech', 'B Pharmacy', 'D Pharmacy',
            'M Pharmacy', 'MCom', 'BOT', 'BDS', 'MDS', 'BPT', 'MPT', 'MBCHB'];


        
        $scope.logout = function () {
            sessionStorage.removeItem("adminDataToken");
            $state.go('admin')
        }
       

        function addConf(reqData) {
            reqData.webinarImage = $scope.imgFileName
            reqData.presenterImage = $scope.pimgFileName

            reqData.channel_id = 'doodleblueTest';
            console.log(reqData);
            dataService.saveData('/api/v1/conferences/create', reqData).then(function (response) {
                 AlertService.success("Conference successfully created")
                console.log(response.data)
                $location.path('/admin-dashboard')
            }, function (response) {
                errorHandler(response);
            });
        }


        function errorHandler(e) {
            console.log(e.toString());
        }
        function getAllConferences() {
            dataService.getData('/api/v1/conferences/getAllConference').then(function (response) {
                vm.confData = response;
                // console.log("&&&&&&&&&&&&&&&&&&&");
                // console.log(vm.confData);
                var date1 = new Date();
                date1.setHours(0, 0, 0, 0);
                console.log(date1)
                vm.liveLectures = response.filter(function (con) {
                    var start_time = new Date(new Date(con.start_time).setHours(0, 0, 0, 0));
                    console.log(start_time)
                    return (start_time.valueOf() == date1.valueOf());
                })
                //
                console.log(vm.liveLectures)

            }, function (response) {

            });
        }
        getAllConferences();

        function upcomingConference() {
            dataService.getData('/api/v1/conferences/upcoming').then(function (response) {
                vm.upcomings = response;
                console.log(vm.upcomings)

            }, function (response) {

            });
        }
        upcomingConference();


        vm.del = del;
        function del(a) {
            console.log(a)
            dataService.deleteData('/api/v1/conferences/delete', a.id).then(function (response) {
                console.log(response.data)
            }, function (response) {
                errorHandler(response);
            });
        }
        vm.getById = getById;
        function getById(a) {
            console.log(a)

            dataService.getDataById('/api/v1/conferences', a).then(function (response) {
                vm.confById = response
                console.log(vm.confById)
            }, function (response) {
                errorHandler(response);
            });
        }



        vm.updateConf = updateConf;
        function updateConf(a) {
            console.log(a)
            dataService.updateData('/api/v1/conferences/update', a.id, a).then(function (response) {
                vm.confById = response.data
            }, function (response) {
                errorHandler(response);
            });
        }


        $scope.$watch('gFiles', function () {
            $scope.upload($scope.gFiles);
        });
        $scope.upload = function (gFiles) {
            if (gFiles && gFiles.length) {
                for (var i = 0; i < gFiles.length; i++) {
                    var file = gFiles[i];
                    if (!file.$error) {
                        console.log(file)
                        Upload.upload({
                            url: '/filesdata',
                            data: {
                                file: file
                            }
                        })
                            .then(function (response) {
                                $timeout(function () {
                                    console.log("ImageFileName" + response);
                                    $scope.fileField = true;
                                    $scope.imgFileName = response.data.imageName;
                                    console.log($scope.imgFileName)
                                });
                            }, function (response) {
                                console.log('Error status: ' + response.status);
                            }, function (evt) {
                                var progressPercentage = parseInt(100.0 *
                                    evt.loaded / evt.total);
                                $scope.progress = progressPercentage + '% ';
                            });
                    }
                }
            }
        }


        function endedConference() {
            dataService.getData('/api/v1/conferences/completed/list').then(function (response) {
                vm.completedConference = response;
            })
        }

        endedConference()
        $scope.$watch('pFiles', function () {
            $scope.uploadPresenter($scope.pFiles);
        });
        $scope.uploadPresenter = function (pFiles) {
            if (pFiles && pFiles.length) {
                for (var i = 0; i < pFiles.length; i++) {
                    var file = pFiles[i];
                    if (!file.$error) {
                        console.log(file)
                        Upload.upload({
                            url: '/filesdata',
                            data: {
                                file: file
                            }
                        })
                            .then(function (response) {
                                $timeout(function () {
                                    console.log("ImageFileName" + response);
                                    $scope.pfileField = true;
                                    $scope.pimgFileName = response.data.imageName;
                                    console.log($scope.pimgFileName)
                                });
                            }, function (response) {
                                console.log('Error status: ' + response.status);
                            }, function (evt) {
                                var progressPercentage = parseInt(100.0 *
                                    evt.loaded / evt.total);
                                $scope.progress = progressPercentage + '% ';
                            });
                    }
                }
            }
        }



        // $(document).ready(function(){

        // });
        // </script>
        //     <script>
        // $(document).ready(function(){
        //     $('#myTabletwo').DataTable();
        // });

    }

}());


