(function () {

    'use strict';

    angular
        .module('app')
        .controller('speakerController', speakerController);

    speakerController.$inject = ['dataService', '$stateParams'];

    /**
     * @memberof module:register
     *
     * CRUD application is performed and also displays the data
     * @requires dataService
     * @ngInject
     */
    function speakerController(dataService, $stateParams) {

        var self = this;
        function getSpeakerData() {
            var url = '/api/v1/home/speaker';
            if ($stateParams.id != null) {
                 dataService.getDataById(url, $stateParams.id).then(successHandler,errorHandler);
           function successHandler(response){
               self.speakerInfo = response;
           }
                }
        }
        getSpeakerData()
        function errorHandler(e){
console.log(e.toString())
        }
    }


}());     
