/**
 * login-controller
 */
(function () {
  'use strict';
  angular
    .module('app')
    .controller('loginController', LoginController)

    .run(function ($rootScope, $state, authService) {
      $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {

        console.log($rootScope.userAuth);

        if (authService.getToken() == undefined) {
          if (toState.name == 'register') {
            $state.go('register')
          }
          else if (toState.name == 'login') {
            $state.go('login')
          }
          else if (toState.name == 'manual-register') {
            $state.go('manual-register')
          }
          else if (toState.name == 'about') {
            $state.go('about')
          }
          else if (toState.name == 'contact') {
            $state.go('contact')
          }
          else if (toState.name == 'about-lecture') {
            $state.go('about-lecture')
          }
          else if (toState.name == 'detail-conference') {
            $state.go('detail-conference')
          }
          else if (sessionStorage.getItem("adminDataToken") && toState.name == 'user-list') {
            $state.go('user-list')
          }
          else if (sessionStorage.getItem("adminDataToken") && toState.name == 'add-webinar') {
            $state.go('add-webinar')
          }
          else if (sessionStorage.getItem("adminDataToken") && toState.name == 'admin-dashboard') {
            $state.go('admin-dashboard')
          }
          else if (toState.name == 'admin') {
            $state.go('admin')
          }

          else {

            $state.go('home')
          }
        }
        else if (authService.getToken()) {
          if (!sessionStorage.getItem("adminDataToken")) {
            if (toState.name == 'user-list') {
              $state.go('home')
            }
            else if (toState.name == 'add-webinar') {
              $state.go('home')
            }
            else if (toState.name == 'admin-dashboard') {
              $state.go('home')
            }


          }




        }


      });


    });

  LoginController.$inject = ['$state', '$scope', '$rootScope', 'dataService', 'authService', 'AlertService', '$location', '$http'];
  /**
     * CRUD application is performed and also displays the data
     * in this login function placed by using authservice
     * @requires $state
     * @requires $rootScope
     * @requires authService
     * @requires ksAlertService
     * @requires $location
     * @ngInject 
     */
  function LoginController($state, $scope, $rootScope, dataService, authService, AlertService, $location, $http) {
    /**
     * Initialize the all function,its load the entire page
     */
    var self = this;
    self.login = login;
    self.userToken = null;
    self.check = check;
    self.toRegister = toRegister;
    /**
     * logout function which work by injecting authservice.login()
     */

    $scope.enabled = true;
    function login(a) {
      authService.login(a.email, a.password)
        .then(function (result) {

          console.log(result);
          self.userToken = result;
          //  AlertService.success("Successfully logged in ");
          $(".modal-backdrop").hide();
          $state.go('dashboard');
        }, function (error) {
          $scope.errMsg = true;
          // AlertService.warn("Invalid credentials");
        });
    };

    function toRegister() {
      $(".modal-backdrop").hide();
      $state.go('register');
    }
    $scope.gmailLogin = function (network) {
      hello(network).login({ scope: "email" }, function (e) {
        console.log(e)
      }).then(function () {
        hello(network).api('me').then(function (json) {
          if (json.email) {

            $http.post('/gmailuser', { mail: json.email }).then(function (response) {
              console.log(response)
              var checked = {};
              checked.email = response.config.data.mail;
              checked.password = 'social';
              login(checked)
            }, function (e) {
              // AlertService.warn('Whoops! ' + e.error.message);
            });
          }
          else {
            $state.go('register');
          }
        })

      })
    }
    $scope.facebookLogin = function (network) {
      self.user = {};
      hello(network).login({ scope: 'email', force: true }, function (e) {
        console.log("login-scope", e);
      }).then(function () {
        $state.go('manual-register');
        hello('facebook').api('me').then(function (data) {
          if (data.id) {
            console.log(data.id)
            $http.post('/userdetail', data).then(function (response) {
              var checked = {};
              checked.email = response.data.email;
              checked.password = 'social';
              login(checked)
            }, function (e) {
              // AlertService('Whoops! ' + e.error.message);
            });
          }
          else {
            $state.go('register')
          }

        })

      })
    }
    $scope.linkedinLogin = function (network) {
      self.user = {};
      hello(network).login({ scope: 'email', force: true }, function (e) {
        console.log("login-scope", e);
      }).then(function () {
        $state.go('manual-register');
        hello(network).api('me').then(function (data) {
          if (data.id) {
            console.log(data.id)
            $http.post('/linkedinLogin', data).then(function (response) {
              var checked = {};
              checked.email = response.data.email;
              checked.password = 'social';
              login(checked)
            }, function (e) {
              //  AlertService('Whoops! ' + e.error.message);
            });
          }
          else {
            $state.go('register')
          }

        })

      })
    }
    ///////Facebook login ///////////        
    function check() {
      FB.getLoginStatus(function (response) {
        if (response.status === 'connected') {

          var user_data = {};

          console.log('Welcome!  Fetching your information.... ');
          FB.api('/me', function (response) {
            console.log(response)
            console.log('Good to see you, ' + response.name + '.' + ' Email: ' + response.email + ' Facebook ID: ' + response.id);
          });

          user_data.uid = response.authResponse.userID;
          user_data.accessToken = response.authResponse.accessToken;
          $http.post('/register/getData', user_data).then(function (response) {
            self.user = response.data;
            console.log(self.user);
            if (self.user.emai) {
              var data = {};
              data.email = self.user.emai;
              data.password = 'social'
              login(data)
            }
            else {
              alert('plz provide valid email id and password')
            }
          }, function (response) {
            self.handleError(response);
          });

        }
        else {
          self.fb_button = true;
          FB.login();
        }
      });

    }
    ////////////////linked in 
    function getProfileData() { // Use the API call wrapper to request the member's basic profile data
      IN.API.Profile("me").fields("id,firstName,lastName,email-address,picture-urls::(original),public-profile-url,location:(name)").result(function (me) {
        var profile = me.values[0];
        var id = profile.id;
        var firstName = profile.firstName;
        var lastName = profile.lastName;
        var emailAddress = profile.emailAddress;
        var pictureUrl = profile.pictureUrls.values[0];
        var profileUrl = profile.publicProfileUrl;
        var country = profile.location.name;
      });
    }

    $scope.sendOtp = function (param_otp) {

      var x = param_otp;
      var atpos = x.indexOf("@");
      var dotpos = x.lastIndexOf(".");
      if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) {
        if (isNaN(param_otp)) {
          alert('Please Enter valid email');
          location.reload();
          return false;
        }
        else {
          if (param_otp.length == 10) {
            dataService.saveData('/sendSms', { num: param_otp }).then(function (response) {
              $scope.OTP = response;
              console.log(response);
              if ($scope.OTP.otp) {
                $scope.showOTP = true;

              }
              else {
                alert('User not found');
                $scope.otpParam = '';
                $(".modal-backdrop").hide();

              }

            }, function (response) {
              alert("user not found");
              $scope.otpParam = '';
              $(".modal-backdrop").hide();
            });
          }
          else {
            alert('Invalid mobile number');
            $scope.otpParam = '';
            $(".modal-backdrop").hide();
          }
        }
      }
      else {

      }

    }


    $scope.changePass = function (a) {
      var userData = $scope.OTP.id
      userData.password = a;

      dataService.updateData('/register', userData._id, userData).then(function (response) {
        console.log(response);
        $scope.showPassword = false;
        $scope.successMsg = true;
      }, function (e) {
        console.log(e)
      })

    }


    $scope.checkOtp = function (a) {
      if (a == $scope.OTP.otp) {
        alert('correct otp');
        $scope.showOTP = false;
        $scope.showPassword = true;
      }
      else {
        alert('incorrect otp')
      }
    }
    /////////////
    $scope.myMessage;

    // var myInt = setInterval(function () {
    //     if (document.getElementById('myMessage').value !== '') {
    //         $scope.myMessage = document.getElementById('myMessage').value;
    //         console.log($scope.myMessage)
    //         var user = $scope.myMessage.split("/");
    //         self.user.first_name = user[0];
    //         self.user.last_name = user[1];
    //         $scope.$apply();
    //         clearInterval(myInt);
    //     }
    // }, 150);
  }


}());












