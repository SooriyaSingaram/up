
(function () {

    'use strict';

    angular
        .module('app')
        .controller('viewConferenceController', viewConferenceController);

    viewConferenceController.$inject = ['dataService', '$stateParams', '$scope', '$location','$window'];

    /**
     * @memberof module:app
     *
     * report based on conference attendance
     * @requires dataService
     * @ngInject
     */
    function viewConferenceController(dataService, $stateParams, $scope, $location,$window) {
        $window.scrollTo(0, 0);
        var vm = this;
        vm.addToFav = addToFav;
        function upcomingConference() {
            dataService.getData('/api/v1/conferences/upcoming').then(function (response) {
                vm.upcomings = response;
                console.log(vm.upcomings)

            }, function (response) {
                if (response.status == 'Payment') {
                    $location.path('/payment')
                }
            });
        }
        upcomingConference();

        function getAllConferences() {
            var mappedId = $stateParams.id;

            dataService.getData('/api/v1/conferences/getAllConference').then(function (response) {
                console.log(response)
                var data = response;
                vm.confById = angular.forEach(data, function (mapped) {

                    if (mapped.id == mappedId) {
                        $scope.conferenceData = mapped;
                        $scope.imageWebinar =  $scope.conferenceData.webinarImage
                        if($scope.imageWebinar){
                            $scope.dynamicImage = true;
                             $scope.webinarImages = 'profiles/'+$scope.imageWebinar;
                        }
                            else{
                                 $scope.dynamicImage = true;
                            }
                        console.log($scope.conferenceData)
                         $scope.copyUrl = $location.absUrl();
                        $scope.whatsappData = "https://web.whatsapp.com/send?text=" + $scope.copyUrl;
                       
                        console.log($location.absUrl())
                        var utc = new Date(Date.now());
                        var d = mapped.start_time
                        var upcoming_date = new Date(d);
                        console.log(upcoming_date);

                        // var diff = (upcoming_date - utc) / 3600000;

                        var hours = Math.abs(upcoming_date - utc) / 36e5;
                        // console.log(hours);

                        console.log(upcoming_date.getTime());
                        console.log(utc.getTime());

                        var diff = Math.abs(upcoming_date.getTime() - utc.getTime()) / 3600000;
                        console.log(diff);
                    }

                })

            })


        }
        getAllConferences();
        function speakerProfile() {
            dataService.getData('/speakers').then(function (response) {
                self.speakers = response;
                console.log(response)
                var res = [];
                for (var x in response) {
                    response.hasOwnProperty(x) && res.push(response[x])
                }
                $scope.speakerValue = [];

                angular.forEach(res, function (key, value) {
                    $scope.speakerValue.push(key[0])
                });
                console.log($scope.speakerValue)
            });
        }

        speakerProfile()


        function addToFav(a) {
            a.favourite = true;
            dataService.updateData('/api/v1/conferences', a._id, a).then(function (response) {
                console.log(response)
            }, function (response) {
                errorHandler(response);
            });


        }


    }


}());     