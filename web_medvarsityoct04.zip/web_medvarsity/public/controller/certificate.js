(function () {

    'use strict';

    angular
        .module('app')
        .controller('certificateController', certificateController)
        .directive('onlyLettersInput', onlyLettersInput);

    certificateController.$inject = ['dataService'];

    /**
     * @memberof module:app
     *
     * report based on conference attendance
     * @requires dataService
     * @ngInject
     */
    function certificateController(dataService) {

        var self = this;
        self.playVid = playVid;
        self.getCurTime = getCurTime;


        function init() {
            console.log("certificate ctrl")
        }
        init()
        var vid = document.getElementById("myVideo");


        function playVid() {
            vid.play();
        }

        function getCurTime() {
            vid.pause();
            var duration = vid.duration;
            var currentTime = vid.currentTime;
            var ninetyPer = duration * 0.9;
            if (currentTime < ninetyPer) {
                alert("You need to attend at least 90% of the session to get the certificate")
            }
            else {
                alert("Your certificate will be provided after 24 hrs")
            }
        }



    }

      function onlyLettersInput() {
      return {
        require: 'ngModel',
        link: function(scope, element, attr, ngModelCtrl) {
          function fromUser(text) {
            var transformedInput = text.replace(/[^a-zA-Z]/g, '');
            //console.log(transformedInput);
            if (transformedInput !== text) {
              ngModelCtrl.$setViewValue(transformedInput);
              ngModelCtrl.$render();
            }
            return transformedInput;
          }
          ngModelCtrl.$parsers.push(fromUser);
        }
      };
    };


}());     