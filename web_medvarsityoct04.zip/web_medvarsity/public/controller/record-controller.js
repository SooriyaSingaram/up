
(function () {

    'use strict';

    angular
        .module('app')
        .controller('recordController', recordController)
        .filter('trustAsResourceUrl', trustAsResourceUrl);



    recordController.$inject = ['dataService', '$stateParams', '$sce'];

    /**
     * @memberof module:app
     *
     * record based on conference 
     * @requires dataService
     * @ngInject
     */
    function recordController(dataService, $stateParams, $sce) {

        var self = this;
        function getConfById() {
            dataService.getDataById('/api/v1/conferences', $stateParams.id).then(function (response) {
                self.conference = response;
                console.log(self.conference)
            }, function (response) {
                errorHandler(response);
            }).then(function () {
                dataService.getDataById('/recordings/record', $stateParams.id).then(function (response) {
                    self.confById = response;
                    self.showEmpty = false;
                    console.log(self.confById);
                    if (self.confById.conference.recording_iframe) self.myRecordings(self.confById.conference.recording_iframe);
                }, function (err) {
                    self.confById = {};
                    self.confById.conference = self.conference;
                    console.log("sdfghjkl;")
                    console.log(self.confById)
                    self.showEmpty = true;

                });
            })
        }
        getConfById()


        self.myRecordings = function (iframe) {

            iframe = iframe.replace(/.*?(https(.*))?\?.*/igm, '$1');
            self.confById.conference.recording_iframe = iframe;

            //  self.trustedHtml = $sce.trustAsHtml(a);
        }

    }

    function trustAsResourceUrl($sce) {
        return function (val) {
            return $sce.trustAsResourceUrl(val);
        };
    }


}());     