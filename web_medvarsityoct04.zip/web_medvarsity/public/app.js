(function () {
    'use strict';

    angular
        .module('app', ['app.data', 'ui.router', 'ngClickCopy', 'ui.calendar', 'ngFileUpload', 'ui.bootstrap', '720kb.socialshare', 'ui.bootstrap.datetimepicker'])
        .config(config)
        .run(run)

    // .run(run);

    function config($stateProvider, $urlRouterProvider, $locationProvider) {
        // default route
        $urlRouterProvider.otherwise("/");
        $locationProvider.html5Mode(true);

        $stateProvider

            .state('home', {
                url: '/',
                templateUrl: 'view/home/home.html',
                controller: 'homeController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('about', {
                url: '/about',
                templateUrl: 'view/home/about.html',
                controller: 'homeController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('contact', {
                url: '/contact',
                templateUrl: 'view/home/contact.html',
                controller: 'homeController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('login', {
                url: '/login',
                templateUrl: 'view/login/login.html',
                controller: 'loginController',
                controllerAs: 'vm',
                enabled: true
            })
            .state('dashboard', {
                url: '/dashboard',
                templateUrl: 'view/home/dashboard.html',
                controller: 'conferenceController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('register', {
                url: '/register',
                templateUrl: 'view/login/register.html',
                controller: 'registerController',
                controllerAs: 'vm',
                enabled: true
            })
            .state('about-lecture', {
                url: '/about-lecture/:id/:Dr',
                templateUrl: 'view/conference/about-lecture.html',
                controller: 'lectureDetailController',

                controllerAs: 'vm',
                enabled: false
            })
            .state('detail-conference', {
                url: '/detail-conference/:id',
                templateUrl: 'view/conference/view-conference.html',
                controller: 'viewConferenceController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('calendar', {
                url: '/calendar',
                templateUrl: 'view/home/calendar.html',
                controller: 'registerController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('manual-register', {
                url: '/manual-register/:id',
                templateUrl: 'view/login/manual-register.html',
                controller: 'signupController',
                controllerAs: 'vm',
                enabled: true
            })
            .state('conference', {
                url: '/conference',
                templateUrl: 'view/conference/addConference.html',
                controller: 'conferenceController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('view-conference', {
                url: '/view-conference',
                templateUrl: 'view/conference/viewAll.html',
                controller: 'conferenceController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('payment', {
                url: '/payment',
                templateUrl: 'view/login/payment.html',
                controller: 'razorpayController',
                // controller:'paymentController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('pay', {
                url: '/pay',
                templateUrl: 'view/ccAvenue.html',
                // controller:'paymentController',
                // controllerAs: 'vm',
                enabled: false
            })
            .state('recording', {
                url: '/recording/:id',
                templateUrl: 'view/conference/view-recording.html',
                controller: 'recordController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('mail', {
                url: '/mail',
                templateUrl: 'view/mailgun/mail.html',
                controller: 'conferenceController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('social-share', {
                url: '/social-share',
                templateUrl: 'view/social-share/social-share.html',
                controller: 'testController',
                controllerAs: 'test',
                enabled: false
            })
            .state('report', {
                url: '/report',
                templateUrl: 'view/conference/report.html',
                controller: 'conferenceController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('speaker', {
                url: '/speaker/:id',
                templateUrl: 'view/speaker/speaker.html',
                controller: 'speakerController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('certificate', {
                url: '/certificate',
                templateUrl: 'view/certificate.html',
                controller: 'certificateController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('admin-dashboard', {
                url: '/admin-dashboard',
                templateUrl: 'view/admin/dashboard.html',
                controller: 'adminController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('admin', {
                url: '/admin',
                templateUrl: 'view/admin/login.html',
                controller: 'adminController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('admin-settings', {
                url: '/admin-settings',
                templateUrl: 'view/admin/settings.html',
                controller: 'adminController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('user-list', {
                url: '/user-list',
                templateUrl: 'view/admin/userlist.html',
                controller: 'adminController',
                controllerAs: 'vm',
                enabled: false
            })
            .state('add-webinar', {
                url: '/add-webinar',
                templateUrl: 'view/admin/webinars.html',
                controller: 'adminController',
                controllerAs: 'vm',
                enabled: false
            });


    }



    // function run($http, $rootScope, $window) {
    //     // add JWT token as default auth header
    //     $http.defaults.headers.common['Authorization'] = 'Bearer ' + $window.jwtToken;

    //     // update active tab on state change
    //     $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
    //         $rootScope.activeTab = toState.data.activeTab;
    //     });
    // }

    // manually bootstrap angular after the JWT token is retrieved from the server
    // $(function () {
    //     // get JWT token from server
    //     $.get('/app/token', function (token) {
    //         window.jwtToken = token;

    //         angular.bootstrap(document, ['app']);
    //     });
    // });


})();


function run($rootScope, $state) {
    $rootScope.$on("$stateChangeSuccess", function (currentRoute, previousRoute) {
        //Change page title, based on Route information
        $rootScope.enabled = $state.current.enabled;
    });
}