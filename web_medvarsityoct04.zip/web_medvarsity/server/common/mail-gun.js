var Mailgun = require('mailgun-js');

module.exports.mail = function(option,cb){
  
//Your api key, from Mailgun’s Control Panel
var api_key = 'key-e6544d8188677889667c14b193b6bb3a';

//Your domain, from the Mailgun Control Panel
var domain = 'sandboxcd2dbac5d955460385d3654eda7c532c.mailgun.org';

//Your sending email address
var from_who = 'surya.doodleblue@gmail.com';
var mailgun = new Mailgun({apiKey: api_key, domain: domain});
    var data = {
    //Specify email data
      from: from_who,
    //The email to contact
      to: option.to,
    //Subject and text data  
      subject: option.sub,
      html: option.content
    }

    //Invokes the method to send emails given the above data with the helper library
    mailgun.messages().send(data, function (err, body) {
        //If there is an error, render the error page
        if (err) {
           return cb(err.toString())
        }
        //Else we can greet    and leave
        else {
            //Here "submitted.jade" is the view file for this landing page 
            //We pass the variable "email" from the url parameter in an object rendered by Jade
           
            return cb(undefined, {
                   // headers: res.headers,
                    statusCode: 200,
                    content:body
                });
                 
             }
    });
}




