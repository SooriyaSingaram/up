var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var subscriberSchema = new Schema({
    mail_id: {
        type: String
    }
});

module.exports = mongoose.model('subscriber', subscriberSchema);
module.exports.schema = subscriberSchema;