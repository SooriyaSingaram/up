
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var paymentSchema = new Schema({


order_id: String,
  tracking_id: String,
  bank_ref_no: String,
  order_status: String,
  payment_mode: String,
  card_name: String,
  status_code: String,
  status_message: String,
  currency: String,
  amount: String,
  billing_name: String,
  billing_address: String,
  billing_city: String,
  billing_state: String,
  billing_zip: String,
  billing_country: String,
  billing_tel: String,
  billing_email: String,
  trans_date: String


});

module.exports = mongoose.model('payment', paymentSchema);
module.exports.schema = paymentSchema;
