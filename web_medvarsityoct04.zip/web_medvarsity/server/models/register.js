var mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

var jwt = require('jwt-simple');

var userSchema = mongoose.Schema({
    first_name: {
        type: String
    },
    last_name: {
        type: String
    },
    email: {
        type: String, unique: true,
    },
    code: {
        type: String
    },
    mobile: {
        type: Number, unique: true,
    },
    payment: {
        type: Boolean
    },
    hash: {
        type: String
    },
    created_date: {
        type: Date
    },
    paid_date: {
        type: Date
    },
    initialPay: {
        type: Number
    },
    qualification: {
        type: String
    },
    mbbsCategory: {
        type: String
    },
    fbId:{
        type:String
    },
    linkedinId:{
       type:String 
    }

});

userSchema.plugin(uniqueValidator);

userSchema.methods.generateJwt = function () {
    var expiry = new Date();
    expiry.setDate(expiry.getDate() + 1);
    return jwt.encode({
        _id: this._id,
        exp: parseInt(expiry.getTime() / 1000),
    }, '123456ABCDEF');
};


module.exports = mongoose.model('user', userSchema);
module.exports.schema = userSchema;


