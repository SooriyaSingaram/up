
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var favouriteSchema = new Schema({


id: String,
conference: Array
});

module.exports = mongoose.model('favourite', favouriteSchema);
module.exports.schema = favouriteSchema;