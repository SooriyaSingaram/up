var Conference = require('../models/conference'),
    performAction = require('../services/commonservice'),
    mailgun = require('../common/mail-gun'),
    express = require('express'),
    elastic = require('../elasticsearch'),
    router = express.Router();


//configure routes
router.route('/create').post(addConference);

router.route('/getAllConference').get(getConference);
router.route('/enter').post(enterConference);

router.route('/register').put(registerConference)

router.route('/upcoming').get(upcoming);
router.route('/recommented').post(recommented);


router.route('/search').post(searchElastic);

router.route('/suggest').post(esSearch);

router.route('/:id').put(addToFavourite).get(getConferenceById);

router.route('/speaker/:id').get(getSpeakerById);

router.route('/update/:id').put(updateConference);

router.route('/delete/:id').delete(deleteConference);
router.route('/record/:id').get(recordConference);


router.route('/getAllReport/:id').get(getReport);

router.route('/reminder/list').get(getReminder);
router.route('/completed/list').get(getCompleted);


router.route('/mail').post(sendMail);

//Get the All the conference Details  
function getConference(req, res) {
    Conference.find({}, function (err, conferences) {
        if (err) {
            resp.status(401).send({
                message: 'Unauthorized Error'
            });
            return
        } else {
            res.json(conferences);
        }

    });
}

//Get the Conference Details for Particular Id
function getConferenceById(req, res) {
    Conference.findOne({
        id: req.params.id
    },
        function (err, conferences) {
            if (err) {
                res.send(err);
                return
            }
            else {
                res.json(conferences);

            }
        });
}

function getSpeakerById(req, res) {
    console.log(req.params.id)
    Conference.find({
        "presenters.presenter_id": req.params.id
    },
        function (err, conferences) {
            if (err) {
                res.send(err);
                return
            }
            else {
                try {
                    console.log(conferences)
                    var arr = conferences[0].presenters;
                    for (var i = 0; i <= arr.length; i++) {
                        if (arr[i].presenter_id == req.params.id) {
                            return res.json(arr[i]);
                            // res.send({data:arr[i]})
                        }
                    }
                } catch (error) {
                    res.status(500).send({
                        message: 'Internal Server Error'
                    });
                }


            }
        });
}

////upcoming events
function upcoming(req, res) {

    var x = new Date();
    var m = x.getMonth() + 3;
    var y = x.getFullYear()
    var reqMon = m < 12 ? m : (m - 12);
    reqMon = reqMon < 10 ? ('0' + reqMon) : reqMon;

    var to = new Date((new Date(((y+1)), reqMon, 1)) - 1)

    var fromDate = startDateFormat(x).substring(0, 10);
    var toDate = startDateFormat(to).substring(0, 10);
    // console.log(fromDate)
    // console.log(toDate)
    Conference.find({ "start_time": { "$gt": fromDate, "$lt": toDate } }, function (err, conferences) {
        if (err) {
            resp.status(401).send({
                message: 'Unauthorized Error'
            });
            return
        } else {
            res.json(conferences);
        }

    });
}
//recommented
function recommented(req, res) {
    console.log()

    Conference.find({ "category": req.body.data }, function (err, conferences) {
        if (err) {
            resp.status(401).send({
                message: 'Unauthorized Error'
            });
            return
        } else {
            res.json(conferences);
        }

    });
}
//Create the New conference
// function addConference(reqs, resp) {
   
//    reqs.body.start_time = startDateFormat(reqs.body.start_time)
//     var payload = JSON.stringify(reqs.body);
//     performAction.getResults(reqs, 'conference', 'POST', payload, function (err, results) {
//         if (err) {
//             resp.status(400).send({
//                 message: 'Please Fill the required fields (channel_id , title)'
//             });
//             return;
//         } else {
            
//             if (results.statusCode == 201) {
               
//                 var dataParse = JSON.parse(results.content)
//                 dataParse.webinarImage = reqs.body.webinarImage;
//                 dataParse.presenterImage = reqs.body.presenterImage;
//                 dataParse.category = reqs.body.category;
//                 dataParse.speakerProfile=reqs.body.speakerProfile;
//                 dataParse.description=reqs.body.description;
//                 dataParse.presenters=[];
//                 dataParse.presenters.push({first_name:reqs.body.presenters.name,email:reqs.body.presenters.email,title:reqs.body.title});
                
//                 var conferences = new Conference(dataParse);
//                 Conference.count({}, function (err, count) {
//                     conferences.save(function (err) {
//                         if (err) {
//                             console.log(err)
//                             resp.send(err);
//                             return
//                         } else {
//                             resp.send({
//                                 message: 'Successfully Added'
//                             });
//                         }

//                     });
//                 })
//             } else {
//                 console.log(results)
//                 resp.status(503).send({
//                     message: 'Error occured'
//                 });
//             }
//         }
//     });


// }

//*********************************************************************************************

function addConference(reqs, resp) {
    // console.log(reqs.body)
   reqs.body.start_time = startDateFormat(reqs.body.start_time)
    var payload = JSON.stringify(reqs.body);
    performAction.getResults(reqs, 'conference', 'POST', payload, function (err, results) {
        if (err) {
            resp.status(400).send({
                message: 'Please Fill the required fields (channel_id , title)'
            });
            return;
        } else {
            // console.log(results)
            if (results.statusCode == 201) {
                // console.log(results.content)
                var dataParse = JSON.parse(results.content)
                // console.log(dataParse.presenters)
                // dataParse.webinarImage = reqs.body.webinarImage;
                // dataParse.presenterImage = reqs.body.presenterImage;
                // dataParse.category = reqs.body.category;
                // dataParse.speakerProfile=reqs.body.speakerProfile;
                // dataParse.description=reqs.body.description;
                // dataParse.presenters=[];
                // dataParse.presenters.push({first_name:reqs.body.presenters.name,email:reqs.body.presenters.email,title:reqs.body.title});
                // setTimeout(function(){
                    addPresenter(reqs,resp,dataParse);
                // },1000)
               
               
            } else {
                console.log(results)
                resp.status(503).send({
                    message: 'Error occured'
                });
            }
        }
    });


}

function addPresenter(reqs, resp,dataParse) {
     reqs.body.start_time = startDateFormat(reqs.body.start_time)
    var data={
        "conference_id":dataParse.id,
        "name":reqs.body.presenters.name,
         "photo_url":"http://assimilate.medvarsity.com/profiles/"+reqs.body.presenterImage,
       // "photo_url":"https://cdn.pixabay.com/photo/2016/03/28/12/35/cat-1285634_960_720.png",
        "presenter_email":reqs.body.presenters.email,
        "presenter_temporary_password":"presenter@med",
        "presenter_first_name":reqs.body.presenters.name,
        "presenter_last_name":reqs.body.presenters.name,
        "can_manage":true,
        "send_email_invite":true,
        "is_moderator": false

    }
    console.log(data);
    
    var payload = JSON.stringify(data);
    performAction.getResults(reqs, 'addPresent', 'POST', payload, function (err, results) {
        if (err) {
            resp.status(400).send({
                message: 'Please Fill the required fields (channel_id , title)'
            });
            return;
        } else {
            console.log(results)
            if (results.statusCode == 201) {
                console.log(results.content)
                // var dataParse = JSON.parse(results.content)
                // process.exit(0)
                console.log(dataParse.presenters)
                dataParse.webinarImage = reqs.body.webinarImage;
                dataParse.presenterImage = reqs.body.presenterImage;
                dataParse.category = reqs.body.category;
                dataParse.speakerProfile=reqs.body.speakerProfile;
                dataParse.description=reqs.body.description;
                dataParse.presenters=[];
                dataParse.presenters.push({first_name:reqs.body.presenters.name,email:reqs.body.presenters.email,title:reqs.body.title});
                
                var conferences = new Conference(dataParse);
               
                    conferences.save(function (err) {
                        if (err) {
                            console.log(err)
                            resp.send(err);
                            return
                        } else {
                            resp.send({
                                message: 'Successfully Added'
                            });
                        }

                    });
               
            } else {
                console.log(results)
                resp.status(503).send({
                    message: 'Error occured'
                });
            }
        }
    });
}
//******************************************************************************
function getCompleted(req, res) {
    var x = new Date();
    var fromDate = startDateFormat(x).substring(0, 10);
    // console.log(fromDate)
    // console.log(toDate)
    Conference.find({ "start_time": { "$lt": fromDate } }, function (err, conferences) {
        if (err) {
            resp.status(401).send({
                message: 'Unauthorized Error'
            });
            return
        } else {
            res.json(conferences);
        }

    });
}
//Add to Fav the Conference Details for Particular Id
function addToFavourite(req, res) {
    Conference.findOne({
        _id: req.params.id
    },
        function (err, conferences) {
            if (err) {
                res.send(err);
                return
            } else {
                for (prop in req.body) {
                    conferences[prop] = req.body[prop];
                }
                conferences.save(function (err) {
                    if (err) {
                        res.send(err);
                    } else {
                        res.json({
                            message: 'Successfully Added to your request!'
                        });
                    }

                });
            }
        });
}

//update conference for particular id
function updateConference(reqs, resp) {
    reqs.body.start_time = startDateFormat(reqs.body.start_time)
    var payload = JSON.stringify(reqs.body);
    performAction.getResults(reqs, 'conference', 'PUT', payload, function (err, results) {
        if (err) {
            console.error(err);
            return;
        }
        if (results.statusCode == 200) {
            var dataParse = JSON.parse(results.content)
            var confData = new Conference(dataParse);
            Conference.findOne({
                'id': reqs.params.id
            },
                function (err, conferences) {
                    if (err) {
                        resp.status(500).send({
                            message: 'Error occured'
                        });
                        return
                    }
                    for (prop in confData) {
                        conferences[prop] = confData[prop];
                    }
                    // save conferences details
                    conferences.save(function (err) {
                        if (err) {
                            resp.status(500).send({
                                message: 'Error occured'
                            });
                            return
                        } else {
                            resp.status(200).json(conferences);
                        }
                    });

                });
        } else {
            resp.status(503).send({
                message: 'Error occured'
            });
        }

    });

}


function recordConference(req, res) {
    performAction.getResults(req, 'conference', 'GET', undefined, function (err, results) {
        if (err) {
            console.log(err);
            console.log("wertyuiopasdfghjklzxcvbnm,.")
            return;
        }
        else {
            if (results.statusCode == 200) {
                res.status(200).json(JSON.parse(results.content));
            }
            else {
                res.status(500).send({ message: 'Internal Server Error' })
            }
            console.log(results);
        }
    })
}

//delete conference
function deleteConference(reqs, resp) {

    performAction.getResults(reqs, 'conference', 'DELETE', undefined, function (err, results) {
        if (err) {
            console.error(err);
            return;
        } else {
            if (results.statusCode == 204) {
                Conference.remove({
                    'id': reqs.params.id
                }, function (err, conferences) {
                    if (err) {
                        resp.send(err);
                        return
                    } else {
                        resp.status(200).send({
                            message: 'Successfully Deleted'
                        });
                    }

                });
            } else {
                resp.status(503).send({
                    message: 'Error occured'
                });
            }
        }
    });
}


function getReport(reqs, resp) {
    performAction.getResults(reqs, 'attendence', 'GET', undefined, function (err, results) {
        if (err) {
            console.error(err);
            return;
        } else {
            resp.status(200).json(JSON.parse(results.content));
        }
    });
}



//Register to a conference
function registerConference(reqs, resp) {

    console.log(reqs.body)
    // reqs.body.start_time = startDateFormat(reqs.body.start_time)
    var payload = JSON.stringify(reqs.body);
    performAction.getResults(reqs, 'register', 'PUT', payload, function (err, results) {
        if (err) {
            resp.status(400).send({
                message: 'Enter Valid Conference'
            });
            return;
        } else {
            // console.log(results)
            if (results.statusCode == 200) {
                console.log("StatusCOde")
                console.log(results.content)
                var dataParse = JSON.parse(results.content)
                // var entering_details = new Conference(dataParse);
                console.log(dataParse);
                enterConference(reqs, resp)
            } else if(results.statusCode === 403 && results.content == '{"error":"You have already registered for this webinar."}'){
                //console.log(results.content, typeof results.content)
                enterConference(reqs, resp)
            } else {
                console.log(results)
                resp.status(503).send({
                    message: 'Error occured'
                });
            }
        }
    });

}

//Enter In to conference
function enterConference(reqs, resp) {

    // reqs.body.start_time = startDateFormat(reqs.body.start_time)
   
    
    var exit_uri = "http://assimilate.medvarsity.com";
    var data={
        "id": reqs.body.id,
        "attendee_email":reqs.body.email,
        "attendee_name":reqs.body.first_name,
        "exit_uri":"http://assimilate.medvarsity.com/#/"
        }
     var payload = JSON.stringify(data);
    performAction.getResults(reqs, 'enter', 'POST', payload, function (err, results) {
        if (err) {
            resp.status(400).send({
                message: 'Enter Valid Conference'
            });
            return;
        } else {
            console.log(results.statusCode)
            if (results.statusCode == 201) {
                // console.log(results.content)
                var dataParse = JSON.parse(results.content)
                // var entering_details = new Conference(dataParse);
                console.log(dataParse);
                resp.status(200).send({url: dataParse.enter_uri})
               
            } else if(results.statusCode == 400){
                resp.status(400).send({message: "This conference is currently not open. Attendees can enter the conference 15 minutes prior to the conference start time."})
            } else {
                console.log(results)
                resp.status(503).send({
                    message: 'Error occured'
                });
            }
        }
    });

}
//Elastic search functionality

function searchElastic(req, res) {
    var searchField = req.body.data;
    Conference.find({
        $text: {
            $search: req.body.data
        }
    }, function (err, conferences) {
        if (err) {
            res.status(404).send({
                message: 'Data Not Found'
            });
            return;

        } else {
            res.json(conferences);
        }
    })
}

function getReminder(req, res) {
    // var date = new Date();
    // var yesterday = new Date(date.setDate(date.getDate() - 1));
    // var tomorrow = new Date(date.setDate(date.getDate() + 1));
    var yesterday = new Date(new Date().setDate(new Date().getDate() - 1));
    var tomorrow = new Date(new Date().setDate(new Date().getDate() + 1));
    var start = startDateFormat(yesterday);
    var end = startDateFormat(tomorrow);

    Conference.find({ reminder: true, start_time: { $gt: start, $lt: end } }, function (err, conferences) {
        if (err) {
            console.log(err);
            res.status(500).send({ message: 'Internal Server Error' })
            return
        }
        else {
            res.json(conferences)
        }
    })

}
function esSearch(req, res) {
    elastic.searchField(req.body.data).then(function (result) {
        console.log(result)
        res.json(result.hits.hits)
    });
}

function sendMail(req, res) {
    if (req.body.eligible == 'Yes') {
        console.log("rtyu")
        //req.body.email
        var options = {
            to: 'surya@askpundit.com',
            sub: 'Certificate',
            content: 'success'
        }
        mailgun.mail(options, function (err, result) {
            if (err) {
                res.status(400).send({ message: 'Email Not send.Please enter valid Email' });
                return
            }
            else {
                return res.status(200).send({ message: 'Successfully sent' })

            }
        })
    }
    else {
        var options = {
            to: 'surya@askpundit.com',
            sub: 'Certificate',
            content: 'Failed'
        }
        mailgun.mail(options, function (err, result) {
            console.log(result)
            if (err) {
                res.status(400).send({ message: 'Email Not send.Please enter valid Email' });
                return
            }
            else {
                return res.status(200).send({ message: 'Successfully sent' })

            }
        })
    }
}
//change date format to required format
function startDateFormat(requ) {
    var now = new Date(requ);
    var pretty = [
        now.getFullYear(),
        '-',
        (now.getMonth() + 1) < 10 ? ('0' + (now.getMonth() + 1)) : now.getMonth() + 1,
        '-',
        now.getDate() < 10 ? ('0' + now.getDate()) : now.getDate(),
        ' ',
        now.getHours() < 10 ? ('0' + now.getHours()) : now.getHours(),
        ':',
        now.getMinutes() < 10 ? ('0' + now.getMinutes()) : now.getMinutes()
    ].join('');
    return pretty;
}

module.exports = router;