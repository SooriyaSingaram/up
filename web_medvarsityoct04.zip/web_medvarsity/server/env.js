var bmApi = {
    "hostname": process.env.BM_HOSTNAME,
    "port": null,
    "headers": {
        "api-key": process.env.BM_APIKEY
    }
};
var countryCode = {
    "hostname": process.env.CO_HOST,
    "path": process.env.CO_PATH,
    "method": "GET"

}

module.exports = {
    bmApi: bmApi,
    countryCode: countryCode

}

