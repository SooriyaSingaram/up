// config/auth.js

// expose our config directly to our application using module.exports
module.exports = {

	'facebookAuth' : {
		'clientID' 		: '312447839230283', // your App ID
		'clientSecret' 	: '0e397483a664140a0a526c92a76e9ff9', // your App Secret
		'callbackURL' 	: 'http://localhost:8080/auth/facebook/callback'
	},

	'twitterAuth' : {
		'consumerKey' 		: 'your-consumer-key-here',
		'consumerSecret' 	: 'your-client-secret-here',
		'callbackURL' 		: 'http://localhost:8080/auth/twitter/callback'
	},

	'googleAuth' : {
		'clientID' 		: '533121796647-fukeo6118irj29n9qup2af648nv9fmr8.apps.googleusercontent.com',
		'clientSecret' 	: 'ju0PL7LStRqvk9EvKVBmTezG',
		'callbackURL' 	: 'http://localhost:8080/'
	},
	'linkedin' : {
		'consumerKey' 		: '81mn240o4xbdc8',
		'clientSecret' 	: 'QR7FlUJJMOzW92uU',
		'callbackURL' 	: 'http://localhost:8080/'
	}

};