// load all the things we need
var passport = require('passport');

var FacebookStrategy = require('passport-facebook').Strategy;
var GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;
var LinkedInStrategy = require('passport-linkedin').Strategy;

var register = require('../models/register');
var configAuth = require('./client-secret'); // use this one for testing

passport.use(new FacebookStrategy({

    clientID: configAuth.facebookAuth.clientID,
    clientSecret: configAuth.facebookAuth.clientSecret,
    callbackURL: configAuth.facebookAuth.callbackURL,
    passReqToCallback: true // allows us to pass in the req from our route (lets us check if a user is logged in or not)

},
    function (accessToken, refreshToken, profile, cb) {
        FBProfile = profile._json;
        return cb(null, profile);
    }));

passport.use(new GoogleStrategy({

    clientID: configAuth.googleAuth.clientID,
    clientSecret: configAuth.googleAuth.clientSecret,
    callbackURL: configAuth.googleAuth.callbackURL

},
    function (token, refreshToken, profile, cb) {
        console.log(profile);
        return cb(null, profile)
    }));

passport.use(new LinkedInStrategy({


    consumerKey: configAuth.linkedin.consumerKey,
    consumerSecret: configAuth.linkedin.clientSecret,
    callbackURL: configAuth.linkedin.callbackURL
},
    function (token, tokenSecret, profile, done) {
        console.log(profile)
    }));