var option = require('../env'),
    request = require('request'),
    http = require("https");



var getResults = function (reqs, objective, type, payload, cb) {
    try {
        if (objective == 'conference') {
            var options = option.bmApi;
            options.method = type;
            if (reqs.params.id) {
                options.path = "/api/v1/conferences/" + reqs.params.id;

            } else {
                options.path = "/api/v1/conferences/";

            }
        }
        else if (objective == 'attendence') {
            var options = option.bmApi;
            options.method = type;
            options.path = "/api/v1/conferences/" + reqs.params.id+'/attendees';
        }
        else if (objective == 'enter') {
            var options = option.bmApi;
            options.method = type;
            options.path = "/api/v1/conferences/enter";
        }
        else if (objective == 'register') {
            var options = option.bmApi;
            options.method = type;
            options.path = "/api/v1/conferences/register";
        }
        else if (objective == 'addPresent') {
            var options = option.bmApi;
            options.method = type;
            options.path = "/api/v1/presenters";
        }
        var req = http.request(options, (res) => {
            var chunks = [];
            res.on("data", (chunk) => {
                chunks.push(chunk)
            })
            res.on('end', () => {
                return cb(undefined, {
                    headers: res.headers,
                    statusCode: res.statusCode,
                    content: Buffer.concat(chunks).toString()
                });
            })
        })


        if (payload) {
            req.write(payload)
        }
        req.end();
    } catch (e) {
        console.log(e)
        return cb(e.toString())
    }
}


module.exports = {
    getResults: getResults
}