var User = require('./models/register');
var mailer = require('./common/send-mail');

module.exports.mailFunc = function (req, res) {
    var mailTo;
    if (req.body.data == 'all') {
        User.find().distinct('email', function (error, ids) {
            if (error) {
                res.status(503).json({
                    message: 'Internal Server Error'
                });
                return
            }
            else {
                mailTo = ids;
                trans()
            }
        });
    }
    else {
        var mailTo = req.body.data
        trans()
    }
    function trans() {
        var sub = "EMAIL SUBJECT";
        var text = "TEXT SAMPLE";
        mailer.trans(mailTo, sub, text, function (err, result) {
            if (err) {
                console.log(err);
                return
            }
            else {
                res.status(200).json({
                    message: result.content
                });
            }

        })
    }


}
