var http = require('http'),
    ccav = require('./ccavutil.js'),
    qs = require('querystring');
var Payment =require('./server/models/payment');

exports.postRes = function(request,response){
    var ccavEncResponse='',
	ccavResponse='',	
	workingKey = '5CFE457C1BC9913761008832B936403C',	//Put in the 32-Bit key shared by CCAvenues.
	ccavPOST = '';
	
        request.on('data', function (data) {
			console.log(data)
	    ccavEncResponse += data;
	    ccavPOST =  qs.parse(ccavEncResponse);
	    var encryption = ccavPOST.encResp;
	    ccavResponse = ccav.decrypt(encryption,workingKey);
console.log(ccavResponse);

        });

//
	request.on('end', function () {
	    // var pData = '';
	    // pData = '<table border=1 cellspacing=2 cellpadding=2><tr><td>'	
	    // pData = pData + ccavResponse.replace(/=/gi,'</td><td>')
	    // pData = pData.replace(/&/gi,'</td></tr><tr><td>')
	    // pData = pData + '</td></tr></table>'
     //        htmlcode = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>Response Handler</title></head><body><center><font size="4" color="blue"><b>Response Page</b></font><br>'+ pData +'</center><br></body></html>';
     //        response.writeHeader(200, {"Content-Type": "text/html"});
	    // response.write(htmlcode);
        var change1 = ccavResponse.replace(/\=/ig,'":"');
        var change2 = change1.replace(/\&/ig,'","');
        var responseData = '{"'+change2+'"}'
         console.log(responseData);
    var requireData = JSON.parse(responseData)
    var payment = new Payment(requireData);
    // Payment.count({}, function (err, count) {
        payment.save(function (err) {
            if (err) {
                response.send(err);
                return
            }

            else {
                response.redirect("http://assimilate.medvarsity.com/");

               response.end();
            }

        });
    })
	   
//}); 	
};

 // 
 //        

